package com.fdapp.supportbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupportBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupportBackendApplication.class, args);
	}

}
