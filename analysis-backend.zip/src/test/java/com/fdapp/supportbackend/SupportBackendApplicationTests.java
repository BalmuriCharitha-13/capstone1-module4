package com.fdapp.supportbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupportBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
